# LBS-to-KG
WebExtension (originally created for Mozilla Firefox, not tested on other browsers) that replaces weight measured in LBS with corresponding weight in KG.
Currently only the english convention is converted (comma as separator between thousands and points to represent floating point numbers). 

Based on example that can be found here: https://github.com/mdn/webextensions-examples/tree/master/emoji-substitution
